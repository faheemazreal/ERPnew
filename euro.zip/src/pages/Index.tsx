import { Navigation } from "@/components/brochure/navigation";
import { HeroSection } from "@/components/brochure/hero-section";
import { IntroductionSection } from "@/components/brochure/introduction-section";
import { StatsSection } from "@/components/brochure/stats-section";
import { FeaturesSection } from "@/components/brochure/features-section";
import { BenefitsSection } from "@/components/brochure/benefits-section";
import { TestimonialsSection } from "@/components/brochure/testimonials-section";
import { ClientLogosSection } from "@/components/brochure/client-logos-section";
import { DemoPreviewSection } from "@/components/brochure/demo-preview-section";
import { PricingSection } from "@/components/brochure/pricing-section";
import { FAQSection } from "@/components/brochure/faq-section";
import { CTASection } from "@/components/brochure/cta-section";
import { FooterSection } from "@/components/brochure/footer-section";
import { BackToTopButton } from "@/components/ui/back-to-top";
import { WhatsAppButton } from "@/components/ui/whatsapp-button";

const Index = () => {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <HeroSection />
      <IntroductionSection />
      <StatsSection />
      <FeaturesSection />
      <BenefitsSection />
      <TestimonialsSection />
      <ClientLogosSection />
      <DemoPreviewSection />
      <PricingSection />
      <FAQSection />
      <CTASection />
      <FooterSection />
      <BackToTopButton />
      <WhatsAppButton />
    </main>
  );
};

export default Index;
